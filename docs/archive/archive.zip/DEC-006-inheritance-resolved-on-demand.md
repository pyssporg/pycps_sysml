---
id: DEC-006
title: Inheritance resolves on demand in the model layer
summary: A definition keeps only its declared members; effective_members merges ancestors on demand, and exporters stay declared-only.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/model-and-policy.md
artifacts:
  - src/pycps_sysml2/model/effective.py
supersedes: []
superseded_by: []
related: [DEC-002, DEC-004]
---

## Context

SysML definitions specialize other definitions, and consumers — metadata
accessors, constraint evaluation, and the artifact implementers — need the whole
member set. Flattening inherited members into the IR at load would make every
later question read a derived copy and would blur which members the source wrote.

## Decision

The IR stays source-faithful: a definition stores its declared members and
`specializes`; `model/effective.py::effective_members` merges ancestors on demand
into `EffectiveMembers` (derived wins by name, cycle-guarded, nothing written
back). Metadata and constraint helpers delegate to it; exporters stay
declared-only. An unknown or wrong-kind supertype is skipped silently, because
the pinned analyzer emits no code for it — the known gap.

## Rationale

One resolver owns the merge, so consumers cannot disagree about inheritance and
the IR still reloads to the declarations the author wrote. Materializing at load
would make the parser responsible for a later consumer's view and would need a
second representation for export.

## Alternatives Considered

- Materialize inherited members during load: every consumer gets a flat model,
  but export can no longer recover the declared set and a cycle becomes a parse
  failure rather than a diagnostic.
- Let each consumer merge its own members: three copies drift, the fault the
  shared metadata helpers already removed.

## Consequences

Positive: one inheritance rule, a source-faithful IR, and unchanged exporters.
Negative: each consumer must opt into the effective view, and an unknown
supertype passes unremarked until the analyzer gains a code for it.

## Verification

`tests/test_inheritance.py` covers ancestor order, derived-wins, value fallback,
cycles, and unknown supertypes; `tests/test_inherited_consumers.py` pins the
metadata and constraint delegation; `tests/test_semantics.py` pins the three
reported specialization codes.

## Review Trigger

A consumer needs a member fact the view cannot express, or the pinned sysmlpy
starts reporting undefined supertypes or definition-kind mismatch.
