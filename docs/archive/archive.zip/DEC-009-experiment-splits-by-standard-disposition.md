---
id: DEC-009
title: Experiment splits by standard disposition
summary: DefaultExperiment mirrors the SSP element, Experiment adds the FMI fields, exporters project by disposition, and implementation is a closed SSP enum.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 03-implementation/core-definitions.md
artifacts:
  - src/pycps_sysml2/definitions/core.sysml
  - src/pycps_sysml2/metadata/roles.py
  - src/pycps_sysml2/metadata/fmu_metadata.py
supersedes: []
superseded_by: []
related: [DEC-007]
---

## Context

DEC-007 bound one four-field `DefaultExperiment` to both standards. SSP 2.0.1's
`TDefaultExperiment` defines only optional `startTime` and `stopTime`, while FMI
2.0.5 defines all four fields as optional doubles with no default, so the shared
container made one standard's fields look native to the other. `implementation`
was also an unchecked string although `ssd:Component/@implementation` closes it
to four values.

## Decision

`DefaultExperiment` declares `startTime`/`stopTime` (SSP);
`Experiment :> DefaultExperiment` adds `stepSize`/`tolerance` (FMI). Start and
stop are required, the other two optional and positive when authored. The FMI
exporter copies every authored field; the SSD exporter copies only
`startTime`/`stopTime`; a local four-field `DefaultExperiment` stays
readable; `implementation` must be `any|ModelExchange|CoSimulation|ScheduledExecution`.

## Rationale

Each standard owns its own experiment shape, so the vocabulary should not make
one artifact's fields look native to the other. A subtype keeps the relation
that lets one container serve both while making the disposition of every field
explicit at the type. Closing `implementation` rejects XML the SSP schema would
refuse, at the point the metadata is read rather than at the exporter.

## Alternatives Considered

- Keep one four-field container: the SSP side must carry fields its schema does
  not define, or drop them without a stated rule.
- Use two unrelated containers: loses the subtype relation that lets an FMI
  experiment also serve SSP.
- Validate `implementation` as a free string: accepts values the SSD schema
  rejects.

## Consequences

- Positive: each disposition is explicit, and the `.ssd`/`modelDescription.xml`
  projection is a documented rule rather than an implementer's accident.
- Negative: a `stepSize` or `tolerance` authored on an experiment is absent from
  `.ssd`; an author targeting both must accept that fidelity limit.
- Naming: `source` and `implementation` are `ssd:Component` attributes, not
  `fmiModelDescription` fields; `FmuMetadata` describes an FMI model packaged as
  an SSP component, so `FmuMetadata`, `FmuModel`, and `fmu_meta` keep their
  names.
- Deliberate non-change: generated and tooling fields stay out of the
  vocabulary — FMI `fmiVersion`, `modelName`, `guid`, `generationTool`,
  `generationDateAndTime`, `variableNamingConvention`, `valueReference`,
  `numberOfEventIndicators`, and the `ModelStructure` indices; SSP `version`,
  `name`, `fileversion`, `id`, geometry, `GraphicalElements`, and `Signature`.

## Verification

`tests/test_metadata_roles.py` and `tests/test_core_definitions.py` pin the
split and the permissive local redeclaration; the experiment fixtures carry the
authored and absent cases; the fmu-metadata fixtures pin the closed
implementation set. The pyssp and pyfmi golden artifacts pin the two
projections.

## Review Trigger

FMI or SSP revises the default-experiment fields or the implementation
enumeration.
