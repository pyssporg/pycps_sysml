---
id: DEC-005
title: Typed containers replace the pyssp_* vocabulary
summary: Special data is carried by typed attribute containers; the name-prefixed attributes and the flat-connector model rule are removed.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/dialect.md
artifacts: []
supersedes: []
superseded_by: []
related: [DEC-002]
---

## Context

The dialect carried a second, name-prefixed vocabulary: `pyssp_default_start_time`,
`pyssp_default_stop_time`, `pyssp_flat_connector`, and the retired
`pyssp_implementation` / `pyssp_parameter_set` names. Every reader had to know
the prefix, generators had to skip those names explicitly, and a typo became
model data that was silently ignored. The typed metadata dialects already
recognized a value by its `attribute def` type, so the prefix was a second rule
for the same job.

## Decision

Special data is a typed attribute container, recognized by type never by name:
`attribute <name> : <Def>;` where `<Def>` specializes a marker, or a `part def`
marker supertype. `DefaultExperiment` carries start and stop;
`Experiment :> DefaultExperiment` also requires a step size. The removed
`pyssp_*` names raise a migration error naming the typed replacement, and the
flat-connector marker rule is deleted because that choice is export-time.

## Rationale

One rule instead of two: a typed definition is visible in the model, resolves
through the same namespace as every other definition, and carries its members
without a prefix convention. A leftover prefix is then unambiguously an error,
not a thing to skip, so a misspelling cannot disappear from an artifact.

## Alternatives Considered

- Keep the prefix alongside typed containers. Two vocabularies drift, and every
  generator needs both rules.
- Keep `pyssp_flat_connector` as model data. It is an export option, not a fact
  about the architecture, so the model would carry writer policy.

## Consequences

This is a breaking 0.3.0 change: `CONTROL_PREFIX`, `ControlAttributes`, the
control-name skips, and the `pyssp_*` names are gone. Implementers migrate
fixtures to the container form and pass `--flat-connector` at export time.
`experiment_attribute` and `read_experiment` take a required keyword, and
`Experiment.step_size` may be `None` for a plain `DefaultExperiment`.

## Verification

`tests/test_control_attributes.py` pins each retired tag's replacement and the
catch-all; `tests/test_metadata_roles.py` covers `DefaultExperiment` without a
step size, an `Experiment` missing one, more than one container, and acceptance
on an exported part and an analysis. Fixtures no longer contain the removed
names, and the full non-slow suite plus ruff pass.

## Review Trigger

A domain needs an attribute that no marker definition can type, or a consumer
cannot migrate a retired name to a typed container.
