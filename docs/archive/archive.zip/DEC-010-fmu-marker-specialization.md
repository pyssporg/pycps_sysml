---
id: DEC-010
title: A local fmu_meta requires the FmuModel marker
summary: A part definition that locally declares fmu_meta must specialize FmuModel, and the dialect reports every offender under the fmu-marker check.
date: 2026-11-20
status: accepted
layers: [architecture, implementation, verification]
state: 02-architecture/dialect.md
artifacts:
  - src/pycps_sysml2/metadata/fmu_metadata.py
  - src/pycps_sysml2/validation.py
  - tests/test_validation.py
  - tests/fixtures/validation/fmu-marker.sysml
supersedes: []
superseded_by: []
related: [DEC-005, DEC-008]
---

## Context

DEC-008 gave `FmuModel` the canonical `fmu_meta : FmuMetadata` slot, so a
definition could specialize the marker and inherit an unfilled slot. FMU
metadata on a definition that did not specialize `FmuModel` still parsed and
resolved: the type-based accessor did not care about the role, and only a later
consumer-specific check noticed the mismatch. That left the marker rule as a
convention rather than part of dialect validation, despite the marker being the
one construct that says a definition is an export unit.

## Decision

`validate_fmu_metadata_marker` rejects every part definition whose own
`attributes` contain `fmu_meta` when `is_fmu_model` is false, naming each
offender and the declaration to author. The check runs as `fmu-marker` after
`fmu-metadata` in the report. The inherited unfilled core slot is not a local
declaration and does not trigger the rule; the `FmuModel` marker definition
itself satisfies `is_fmu_model` and is never an offender.

## Rationale

The marker already states what the definition is for, so the metadata may not
appear without it. Checking the local declaration rather than the effective
member view preserves an unauthored `:> FmuModel` as valid, while still letting
any inherited concrete metadata resolve through the effective view. A stable
report code makes the rule visible to an author in the same pass as every other
dialect failure instead of surfacing later in a consumer.

## Alternatives Considered

- Keep the rule as convention and let consumers reject the mismatch: leaves the
  dialect unable to answer what is wrong with the document, and repeats the rule
  in each consumer.
- Trigger on the effective member view: an inherited unfilled core slot would
  make every `:> FmuModel` definition an offender and erase DEC-008's unauthored
  state.
- Trigger on the attribute type instead of its name: metadata is recognized by
  type, but the role requirement is specifically about the marker, and a local
  same-name slot is the declaration that claims the role.

## Consequences

- Positive: the marker rule is dialect validation with a stable code, every
  offender is named in one pass, and an unauthored `FmuModel` remains valid.
- Negative: a model that intends metadata without the marker now fails earlier
  and must add `:> FmuModel`; the existing fixtures that used the convention
  carry the base explicitly.
- Deliberate non-change: the inherited slot stays skipped, and the marker
  definition remains its own valid instance.

## Verification

`tests/test_validation.py` asserts the `fmu-marker` code and the exact offender
message from `tests/fixtures/validation/fmu-marker.sysml`, and drives the
validator over `tests/fixtures/fmu-model/component.sysml`, where `Comp` and
`Nested` specialize `FmuModel` and `Unmarked` is the negative case. The same
module verifies that the core `FmuModel` definition reports `is_fmu_model` and
produces no offender. `python3 -m pytest -m "not slow" -q` passes 352 tests with
1 skipped, and `ruff check src tests` is clean.

## Review Trigger

A role marker other than `FmuModel` becomes a legal home for local FMU metadata,
or the inherited slot and a local declaration need to be treated the same way.
