---
id: DEC-007
title: Sourced metadata base and optional experiment tolerance
summary: FmuMetadata and SspMetadata share SourcedMetadata, and DefaultExperiment carries an optional, positive FMI tolerance with no numeric defaults.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 03-implementation/core-definitions.md
artifacts:
  - src/pycps_sysml2/definitions/core.sysml
  - src/pycps_sysml2/metadata/roles.py
supersedes: []
superseded_by: []
related: [DEC-005]
---

## Context

FMI 2.0.5 and SSP 2.0 define no numeric defaults for the default-experiment
fields, so an absent value must stay absent and each implementer keeps its own
fallback. The dialect nevertheless excluded `tolerance` from the experiment
container, which would have forced the FMI implementer to invent a private
attribute or a default. `FmuMetadata` and `SspMetadata` also declared `source`
separately, duplicating one artifact-source concept in two schemas.

## Decision

`definitions/core.sysml` gains `SourcedMetadata { source : String }`; `FmuMetadata`
and `SspMetadata` specialize it and keep their extra members. `DefaultExperiment`
gains an optional `tolerance : Real` on the base, not only on `Experiment`;
`EXPERIMENT_FIELDS` and `Experiment` carry it, `None` when unauthored, read
through effective members and rejected when not positive. No field authors a
numeric default.

## Rationale

One base owns the artifact-source name, matching the one-dialect-owner rule.
Tolerance is the FMI 2.0 default-experiment attribute, so binding it on the
shared base is where an implementation can read authored data without inventing
values. The earlier exclusion is reversed because the alternative was a private
FMI attribute or an assumed numeric default, and neither belongs to the dialect.

## Alternatives Considered

- Keep tolerance out of the experiment and let pyfmi read a private attribute:
  re-declares a marker outside its owner.
- Put tolerance only on `Experiment`: a plain `DefaultExperiment` could not
  carry an FMI tolerance.
- Author FMI defaults in the vocabulary: invents values that FMI 2.0.5 and
  SSP 2.0 do not define.

## Consequences

- Positive: one source declaration, one optional tolerance read the same way by
  every consumer, and absent values stay absent.
- Negative: SSP has no tolerance, so its implementer must drop the value, and
  every consumer must preserve `None` rather than fall back.
- Deliberate non-change: FMI authoring attributes — guid policy, modelName
  override, capabilities, units, and declared causality — remain non-goals and
  are not bound.

## Verification

`tests/test_metadata_roles.py` covers an authored tolerance, an absent one, and
a non-positive rejection; `tests/test_core_definitions.py` pins the vocabulary;
`tests/fixtures/experiment/tolerance.sysml` carries the three cases.

## Review Trigger

FMI revises the default-experiment fields, or SSP gains a tolerance attribute.
