---
id: DEC-008
title: Role markers own a canonical metadata slot
summary: SspModel and FmuModel declare canonical metadata slots; an inherited unfilled slot means no metadata, while a locally used schema stays rejected.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/dialect.md
artifacts:
  - src/pycps_sysml2/definitions/core.sysml
  - src/pycps_sysml2/metadata/helpers.py
  - src/pycps_sysml2/metadata/fmu_metadata.py
  - src/pycps_sysml2/metadata/ssp_metadata.py
supersedes: []
superseded_by: []
related: [DEC-005, DEC-007]
---

## Context

DEC-005 made special data a typed container recognized by type, but `SspModel`
and `FmuModel` stayed empty markers, so every author restated the canonical
metadata usage and an FMU model could not express "no metadata authored yet"
without also looking like a schema misuse. The dialect rejected a usage typed by
`FmuMetadata` or `SspMetadata` directly because the schema is a shared base, not
a concrete container: it carries the member contract but no authored values, so
accepting it would conflate "the schema is in play" with "metadata was
authored" and would let an abstract type define artifact data.

## Decision

`SspModel` declares `ssp_meta : SspMetadata` and `FmuModel` declares `fmu_meta : FmuMetadata`; `Analysis` stays empty and no other member changes.
`is_inherited_schema_slot` is true for the canonical slot name when the definition does not declare it and it resolves to the marker.
Both `_metadata_usage` helpers skip that inherited unfilled slot: an unauthored `:> FmuModel`/`:> SspModel` model returns `None` and `require_fmu_metadata` says "no FMU metadata".
A locally declared usage typed by the schema itself still raises "schema directly".
A local same-name concrete usage shadows the slot; a differently named concrete container is accepted and the placeholder ignored.
No new core key is added; the include still requires `private import PysspCore::*;` for the marker types to resolve.

## Rationale

The marker is the one place that already names the role, so it is the one place
that should name the role's canonical slot. Declaring the slot once keeps the
one-dialect-owner rule intact, distinguishes unauthored metadata from a schema
misuse, and lets a model specialize a marker before its metadata exists. The
direct-schema rejection remains because the alternative would make the shared
base a valid data container and erase the difference between contract and value.

## Alternatives Considered

- Leave the markers empty and require every author to declare the container:
  repeats one contract in every model and gives no unauthored state.
- Accept a usage typed by the schema directly: conflates the shared base with a
  concrete container and lets an abstract type carry artifact data.
- Make the slot mandatory with a default value: invents metadata a model never
  authored and hides the missing case from `require_fmu_metadata`.

## Consequences

- Positive: a role marker states its metadata slot once; unauthored metadata is
  `None` rather than an error; a concrete fill works by same-name shadowing or
  any other usage name.
- Negative: both metadata dialects carry a slot-aware special case, and a model
  that authors nothing no longer fails at the accessor but at the later
  `require_fmu_metadata` check.
- Deliberate non-change: a locally declared schema-typed usage and multiple
  metadata containers stay errors, and an unimported core still does not resolve
  the marker.

## Verification

`tests/test_core_definitions.py` pins the two slots and the empty `Analysis`;
`tests/test_metadata_dialects.py` covers the inherited unfilled slot,
same-name shadowing, a differently named fill, and the direct-schema rejection;
`tests/fixtures/fmu-metadata/role-slot.sysml` carries the unauthored and filled
cases, and `tests/test_validation.py` pins the "no FMU metadata" report.

## Review Trigger

A domain needs a different canonical slot name, more than one metadata container
per marker, or a role marker whose slot must be mandatory.
